
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<!-- push external head elements to head -->
<?php $__env->startPush('head'); ?>

<link rel="stylesheet" href="<?php echo e(asset('plugins/weather-icons/css/weather-icons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/owl.carousel/dist/assets/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/owl.carousel/dist/assets/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/chartist/dist/chartist.min.css')); ?>">
<?php $__env->stopPush(); ?>

<div class="container-fluid">
    <div class="row">
        <!-- page statustic chart start -->
        <div class="col-xl-3 col-md-6">
            <div class="card card-red text-white">
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="mb-0"><?php echo e(__('2,563')); ?></h4>
                            <p class="mb-0"><?php echo e(__('Products')); ?></p>
                        </div>
                        <div class="col-4 text-right">
                            <i class="fas fa-cube f-30"></i>
                        </div>
                    </div>
                    <div id="Widget-line-chart1" class="chart-line chart-shadow"></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card card-blue text-white">
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="mb-0"><?php echo e(__('3,612')); ?></h4>
                            <p class="mb-0"><?php echo e(__('Orders')); ?></p>
                        </div>
                        <div class="col-4 text-right">
                            <i class="ik ik-shopping-cart f-30"></i>
                        </div>
                    </div>
                    <div id="Widget-line-chart2" class="chart-line chart-shadow"></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card card-green text-white">
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="mb-0"><?php echo e(__('865')); ?></h4>
                            <p class="mb-0"><?php echo e(__('Customers')); ?></p>
                        </div>
                        <div class="col-4 text-right">
                            <i class="ik ik-user f-30"></i>
                        </div>
                    </div>
                    <div id="Widget-line-chart3" class="chart-line chart-shadow"></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card card-yellow text-white">
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="mb-0"><?php echo e(__('35,500')); ?></h4>
                            <p class="mb-0"><?php echo e(__('Sales')); ?></p>
                        </div>
                        <div class="col-4 text-right">
                            <i class="ik f-30">৳</i>
                        </div>
                    </div>
                    <div id="Widget-line-chart4" class="chart-line chart-shadow"></div>
                </div>
            </div>
        </div>
        <!-- page statustic chart end -->

        <!-- Application Sales end -->
    </div>
</div>
<!-- push external js -->
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('plugins/owl.carousel/dist/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/chartist/dist/chartist.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/flot-charts/jquery.flot.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('plugins/flot-charts/jquery.flot.categories.js')); ?>"></script> -->
<script src="<?php echo e(asset('plugins/flot-charts/curvedLines.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/flot-charts/jquery.flot.tooltip.min.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/amcharts/amcharts.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/amcharts/serial.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/amcharts/themes/light.js')); ?>"></script>


<script src="<?php echo e(asset('js/widget-statistic.js')); ?>"></script>
<script src="<?php echo e(asset('js/widget-data.js')); ?>"></script>
<script src="<?php echo e(asset('js/dashboard-charts.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-starter\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>