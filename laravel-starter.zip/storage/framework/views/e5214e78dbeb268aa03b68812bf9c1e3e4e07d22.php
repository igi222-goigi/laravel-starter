<script src="<?php echo e(asset('all.js')); ?>"></script>
<!-- Stack array for including inline js or scripts -->
<?php echo $__env->yieldPushContent('script'); ?>

<script src="<?php echo e(asset('dist/js/theme.js')); ?>"></script>
<script src="<?php echo e(asset('js/chat.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\laravel-starter\resources\views/include/script.blade.php ENDPATH**/ ?>