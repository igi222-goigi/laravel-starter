<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">
            v3.2.0 <?php echo e(__('Copyright © '.date("Y"))); ?> <a href="https://arthemic.com">Arthemic</a>
            <i class="fa fa-heart text-danger"></i>
        </span>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\laravel-starter\resources\views/include/footer.blade.php ENDPATH**/ ?>