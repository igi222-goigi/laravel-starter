<div class="app-sidebar colored">
    <div class="sidebar-header">
        <a class="header-brand" href="<?php echo e(route('dashboard')); ?>">
            <div class="logo-img">
                <img height="30" src="<?php echo e(asset('img/logo_white.png')); ?>" class="header-brand-img" title="RADMIN">
            </div>
        </a>
        <div class="sidebar-action"><i class="ik ik-arrow-left-circle"></i></div>
        <button id="sidebarClose" class="nav-close"><i class="ik ik-x"></i></button>
    </div>

    <?php
    $segment1 = request()->segment(1);
    $segment2 = request()->segment(2);
    ?>

    <div class="sidebar-content">
        <div class="nav-container">
            <nav id="main-menu-navigation" class="navigation-main">
                <div class="nav-item <?php echo e(($segment1 == 'dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>"><i class="ik ik-bar-chart-2"></i><span><?php echo e(__('Dashboard')); ?></span></a>
                </div>

                <div class="nav-lavel"><?php echo e(__('Layouts')); ?> </div>
                <div class="nav-item <?php echo e(($segment1 == 'banners') ? 'active open' : ''); ?> has-sub">
                    <a href="#"><i class="ik ik-user"></i><span><?php echo e(__('Banner Management')); ?></span></a>
                    <div class="submenu-content">
                        <!-- only those have manage_user permission will get access -->
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_banners')): ?>
                        <a href="<?php echo e(url('banners')); ?>" class="menu-item <?php echo e(($segment1 == 'banners') ? 'active' : ''); ?>"><?php echo e(__('Banners')); ?></a>
                        <a href="<?php echo e(url('banners/create')); ?>" class="menu-item <?php echo e(($segment1 == 'banners' && $segment2 == 'create') ? 'active' : ''); ?>"><?php echo e(__('Add Banners')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="nav-lavel"><?php echo e(__('Users Management')); ?> </div>
                <div class="nav-item <?php echo e(($segment1 == 'banners') ? 'active open' : ''); ?> has-sub">
                    <a href="#"><i class="ik ik-doctor"></i><span><?php echo e(__('Doctor Management')); ?></span></a>
                    <div class="submenu-content">
                        <!-- only those have manage_user permission will get access -->
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_banners')): ?>
                        <a href="<?php echo e(url('doctor')); ?>" class="menu-item <?php echo e(($segment1 == 'doctor') ? 'active' : ''); ?>"><?php echo e(__('Doctor')); ?></a>
                        <a href="<?php echo e(url('doctor/create')); ?>" class="menu-item <?php echo e(($segment1 == 'doctor' && $segment2 == 'create') ? 'active' : ''); ?>"><?php echo e(__('Add Doctor')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="nav-item <?php echo e(($segment1 == 'banners') ? 'active open' : ''); ?> has-sub">
                    <a href="#"><i class="ik ik-user"></i><span><?php echo e(__('Agent Management')); ?></span></a>
                    <div class="submenu-content">
                        <!-- only those have manage_user permission will get access -->
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_banners')): ?>
                        <a href="<?php echo e(url('agent')); ?>" class="menu-item <?php echo e(($segment1 == 'agent') ? 'active' : ''); ?>"><?php echo e(__('Agent')); ?></a>
                        <a href="<?php echo e(url('agent/create')); ?>" class="menu-item <?php echo e(($segment1 == 'agent' && $segment2 == 'create') ? 'active' : ''); ?>"><?php echo e(__('Add Agent')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="nav-item <?php echo e(($segment1 == 'banners') ? 'active open' : ''); ?> has-sub">
                    <a href="#"><i class="ik ik-user"></i><span><?php echo e(__('Patient Management')); ?></span></a>
                    <div class="submenu-content">
                        <!-- only those have manage_user permission will get access -->
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_banners')): ?>
                        <a href="<?php echo e(url('patient')); ?>" class="menu-item <?php echo e(($segment1 == 'patient') ? 'active' : ''); ?>"><?php echo e(__('Patient')); ?></a>
                        <a href="<?php echo e(url('patient/create')); ?>" class="menu-item <?php echo e(($segment1 == 'patient' && $segment2 == 'create') ? 'active' : ''); ?>"><?php echo e(__('Add Patient')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="nav-lavel"><?php echo e(__('Administative Management')); ?> </div>
                <div class="nav-item <?php echo e(($segment1 == 'users' || $segment1 == 'roles'||$segment1 == 'permission' ||$segment1 == 'user') ? 'active open' : ''); ?> has-sub">
                    <a href="#"><i class="ik ik-user"></i><span><?php echo e(__('Adminstrator')); ?></span></a>
                    <div class="submenu-content">
                        <!-- only those have manage_user permission will get access -->
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_user')): ?>
                        <a href="<?php echo e(url('users')); ?>" class="menu-item <?php echo e(($segment1 == 'users') ? 'active' : ''); ?>"><?php echo e(__('Users')); ?></a>
                        <a href="<?php echo e(url('user/create')); ?>" class="menu-item <?php echo e(($segment1 == 'user' && $segment2 == 'create') ? 'active' : ''); ?>"><?php echo e(__('Add User')); ?></a>
                        <?php endif; ?>
                        <!-- only those have manage_role permission will get access -->
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_roles')): ?>
                        <a href="<?php echo e(url('roles')); ?>" class="menu-item <?php echo e(($segment1 == 'roles') ? 'active' : ''); ?>"><?php echo e(__('Roles')); ?></a>
                        <?php endif; ?>
                        <!-- only those have manage_permission permission will get access -->
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_permission')): ?>
                        <a href="<?php echo e(url('permission')); ?>" class="menu-item <?php echo e(($segment1 == 'permission') ? 'active' : ''); ?>"><?php echo e(__('Permission')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel-starter\resources\views/include/sidebar.blade.php ENDPATH**/ ?>