<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">
            v3.2.0 {{ __('Copyright © '.date("Y"))}} <a href="https://arthemic.com">Arthemic</a>
            <i class="fa fa-heart text-danger"></i>
        </span>
    </div>
</footer>